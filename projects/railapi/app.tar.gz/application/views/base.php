<?php $this->load->view('inc/header.php'); ?>
<?php $this->load->view($content); ?>
<?php $this->load->view('inc/footer.php'); ?>
