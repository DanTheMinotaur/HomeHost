</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0-beta/js/materialize.min.js"></script>
<script>
	(function() {
		document.addEventListener('DOMContentLoaded', function() {
			var elems = document.querySelectorAll('.collapsible');
			var options = {};
			var instances = M.Collapsible.init(elems, options);
		});
	})();
</script>
</body>
</html>
